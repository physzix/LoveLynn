# Valentine Page

## Run locally
Open `index.html` in your browser.

## Add the GIF
Put your mind-exploding GIF at:

`assets/mind-blown.gif`

## Deploy with GitHub Pages
1. Create a new GitHub repo and push this folder.
2. In GitHub: **Settings** -> **Pages**.
3. **Build and deployment**: Source = **Deploy from a branch**.
4. Branch = `main` (or `master`), folder = `/root`.
5. Wait for the Pages URL to appear.
